# 计划追踪 · iOS 工程（可选）

这是给「想在 iPhone 上安装真正 App（不是网页）」的人准备的 Xcode 工程。
普通用户**不需要**这个东西：直接用 Safari 打开 iOS 版页面 → 分享 → 添加到主屏幕，效果完全一样。

## 编译步骤（需要一台 Mac）

1. 安装 Xcode（App Store 免费下载，约 10 GB）。
2. 双击 `计划追踪.xcodeproj`。
3. 左侧选中工程 → TARGETS「计划追踪」→ Signing & Capabilities：
   - Team 选你的 Apple ID（Xcode → Settings → Accounts 里先登录，免费账号就行）；
   - Bundle Identifier 改成没人用过的，例如 `com.你的名字.plantracker`。
4. 顶部设备选你的 iPhone（用数据线连 Mac），点 ▶️ 运行。
5. 首次运行手机会提示「不受信任的开发者」：设置 → 通用 → VPN与设备管理 → 信任你的 Apple ID。

免费 Apple ID 签名的 App 有效期 7 天，到期重连 Mac 再运行一次即可（数据不会丢，存在 App 沙盒里）。

## 工程结构

```
计划追踪.xcodeproj       Xcode 工程
PlanTracker/
  AppDelegate.swift            入口
  TrackerViewController.swift  WKWebView 壳（文件选择 / 导出分享 / 外链）
  Info.plist
  Assets.xcassets              图标
  www/index.html               应用本体（就是 iOS 网页版那份 HTML）
```

想改功能？改 `www/index.html` 即可，和网页版同一份代码；改完重新运行就生效。

## 与 iOS 网页版的差别

| | 网页版（添加到主屏幕） | 原生壳 |
|---|---|---|
| 安装方式 | Safari 分享 → 添加到主屏幕 | Xcode 编译安装 |
| 是否需要 Mac | 不需要 | 需要 |
| 数据存储 | Safari 本地存储 | App 沙盒本地存储 |
| 后台通知 | 不支持（打开 App 时补提醒） | 暂未实现 |
| 更新 | 刷新即最新 | 重新编译 |

两边数据不通，用「🔗 同步码」搬一次即可（数据页 → 生成同步码 / 从同步码恢复）。
